package com.example.quizapp;

import android.app.Application;
import androidx.room.Room;
import com.example.quizapp.data.Question;
import com.example.quizapp.data.QuestionDao;
import com.example.quizapp.data.QuizDatabase;
import java.util.List;

public class QuizApplication extends Application {
    private QuizDatabase database;

    @Override
    public void onCreate() {
        super.onCreate();
        database = QuizDatabase.getDatabase(this);
        initializeDatabase();
    }

    private void initializeDatabase() {
        new Thread(() -> {
            QuestionDao questionDao = database.questionDao();
            if (questionDao.getRandomQuestion() == null) {
                List<Question> initialQuestions = List.of(
                    new Question(
                        "What is the capital of France?",
                        "London",
                        "Paris",
                        "Berlin",
                        "Madrid",
                        2
                    ),
                    new Question(
                        "Which planet is known as the Red Planet?",
                        "Venus",
                        "Mars",
                        "Jupiter",
                        "Saturn",
                        2
                    ),
                    new Question(
                        "What is the largest mammal?",
                        "Elephant",
                        "Blue Whale",
                        "Giraffe",
                        "Hippopotamus",
                        2
                    )
                );
                questionDao.insertAll(initialQuestions);
            }
        }).start();
    }

    public QuizDatabase getDatabase() {
        return database;
    }
}
