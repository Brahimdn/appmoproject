package com.example.quizapp;

import android.content.Intent;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import com.example.quizapp.data.Question;
import com.example.quizapp.data.QuestionDao;
import com.example.quizapp.data.QuizDatabase;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class QuizActivity extends AppCompatActivity {
    private TextView questionText;
    private RadioGroup answerRadioGroup;
    private Button submitButton;
    private TextView resultText;
    private Question currentQuestion;
    private ExecutorService executorService;
    private static final int[] ANSWER_IDS = {
            R.id.answer1,
            R.id.answer2,
            R.id.answer3,
            R.id.answer4
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        questionText = findViewById(R.id.questionText);
        answerRadioGroup = findViewById(R.id.answerRadioGroup);
        submitButton = findViewById(R.id.submitButton);
        resultText = findViewById(R.id.resultText);

        executorService = Executors.newSingleThreadExecutor();
        submitButton.setOnClickListener(v -> checkAnswer());

        loadNewQuestion();
    }

    void loadNewQuestion() {
        executorService.execute(() -> {
            QuizDatabase db = ((QuizApplication) getApplication()).getDatabase();
            Question question = db.questionDao().getRandomQuestion();
            currentQuestion = question;

            runOnUiThread(() -> {
                questionText.setText(question.getQuestionText());
                ((RadioButton) answerRadioGroup.getChildAt(0)).setText(question.getAnswer1());
                ((RadioButton) answerRadioGroup.getChildAt(1)).setText(question.getAnswer2());
                ((RadioButton) answerRadioGroup.getChildAt(2)).setText(question.getAnswer3());
                ((RadioButton) answerRadioGroup.getChildAt(3)).setText(question.getAnswer4());
                answerRadioGroup.clearCheck();
                resultText.setVisibility(TextView.GONE);
            });
        });
    }

    private void checkAnswer() {
        int selectedId = answerRadioGroup.getCheckedRadioButtonId();
        if (selectedId == -1) return;

        int selectedPosition = -1;
        for (int i = 0; i < ANSWER_IDS.length; i++) {
            if (selectedId == ANSWER_IDS[i]) {
                selectedPosition = i + 1;
                break;
            }
        }

        if (selectedPosition != -1) {
            boolean isCorrect = selectedPosition == currentQuestion.getCorrectAnswer();
            resultText.setText(isCorrect ? getString(R.string.correct_answer) : getString(R.string.wrong_answer));
            resultText.setVisibility(TextView.VISIBLE);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadNewQuestion();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executorService.shutdown();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        loadNewQuestion();
    }
}