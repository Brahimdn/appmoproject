# Journal des Mises à Jour - QuizApp

## Version 1.1.0 - 17/05/2025

### Nouvelles Fonctionnalités

1. **Changement Automatique de Question**
   - Les questions changent automatiquement lors de la réception d'un appel téléphonique
   - Les questions changent automatiquement lors de la réception d'un SMS
   - Notification visuelle (Toast) lors du changement de question

2. **Gestion des Permissions**
   - Demande des permissions nécessaires pour les appels et SMS
   - Gestion élégante des refus de permissions
   - Messages d'information pour guider l'utilisateur

3. **Système de Score**
   - Comptage des bonnes réponses
   - Affichage du score final
   - Possibilité de recommencer le quiz

4. **Améliorations de l'Interface**
   - Compteur de questions (ex: "Question 1/5")
   - Meilleure gestion des états de l'application
   - Messages de débogage pour le suivi des événements

### Corrections de Bugs

- Correction de l'enregistrement des récepteurs de broadcast
- Meilleure gestion du cycle de vie de l'application
- Correction des fuites mémoire potentielles

### Améliorations Techniques

- Refactoring du code pour une meilleure maintenabilité
- Ajout de commentaires détaillés
- Gestion des erreurs améliorée

### Prochaines Étapes

1. Ajouter plus de questions à la base de données
2. Implémenter des effets sonores
3. Ajouter des animations lors du changement de question
4. Permettre la personnalisation du thème

---
*Dernière mise à jour : 17/05/2025*
