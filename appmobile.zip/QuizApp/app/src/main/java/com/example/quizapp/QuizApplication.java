package com.example.quizapp;

import android.app.Application;
import android.content.IntentFilter;
import android.telephony.TelephonyManager;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import com.example.quizapp.data.Question;
import com.example.quizapp.data.QuestionDao;
import com.example.quizapp.data.QuizDatabase;
import com.example.quizapp.receiver.CallReceiver;
import com.example.quizapp.receiver.SmsReceiver;
import java.util.List;

public class QuizApplication extends Application {
    private QuizDatabase database;

    @Override
    public void onCreate() {
        super.onCreate();
        database = QuizDatabase.getDatabase(this);
        initializeDatabase();
        registerReceivers();
    }
    
    private void registerReceivers() {
        // Enregistrer le récepteur d'appels
        CallReceiver callReceiver = new CallReceiver();
        IntentFilter callFilter = new IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED);
        registerReceiver(callReceiver, callFilter);
        
        // Enregistrer le récepteur de SMS
        SmsReceiver smsReceiver = new SmsReceiver();
        IntentFilter smsFilter = new IntentFilter("android.provider.Telephony.SMS_RECEIVED");
        registerReceiver(smsReceiver, smsFilter);
    }

    private void initializeDatabase() {
        new Thread(() -> {
            QuestionDao questionDao = database.questionDao();
            if (questionDao.getRandomQuestion() == null) {
                List<Question> initialQuestions = List.of(
                    new Question(
                        "What is the capital of France?",
                        "London",
                        "Paris",
                        "Berlin",
                        "Madrid",
                        2
                    ),
                    new Question(
                        "Which planet is known as the Red Planet?",
                        "Venus",
                        "Mars",
                        "Jupiter",
                        "Saturn",
                        2
                    ),
                    new Question(
                        "What is the largest mammal?",
                        "Elephant",
                        "Blue Whale",
                        "Giraffe",
                        "Hippopotamus",
                        2
                    )
                );
                questionDao.insertAll(initialQuestions);
            }
        }).start();
    }

    public QuizDatabase getDatabase() {
        return database;
    }
}
