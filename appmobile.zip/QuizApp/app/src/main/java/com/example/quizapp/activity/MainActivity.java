package com.example.quizapp.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import androidx.appcompat.app.AppCompatActivity;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.example.quizapp.R;
import com.example.quizapp.database.QuizDbHelper;
import com.example.quizapp.model.Question;
import com.example.quizapp.receiver.CallReceiver;
import com.example.quizapp.receiver.SmsReceiver;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private static final int TOTAL_QUESTIONS = 5; // Nombre total de questions pour le quiz
    
    private QuizDbHelper dbHelper;
    private Question currentQuestion;
    private int currentQuestionNumber = 0;
    private int score = 0;
    
    private TextView questionText;
    private RadioGroup choicesGroup;
    private RadioButton choice1, choice2, choice3, choice4;
    private Button submitButton;
    private TextView questionCounter;
    
    private final BroadcastReceiver callReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            // Changer de question lorsqu'un appel est reçu
            resetQuiz();
            loadNewQuestion();
            Toast.makeText(MainActivity.this, "Appel reçu - Nouveau quiz chargé", Toast.LENGTH_SHORT).show();
        }
    };

    private final BroadcastReceiver smsReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            // Changer de question lorsqu'un SMS est reçu
            resetQuiz();
            loadNewQuestion();
            Toast.makeText(MainActivity.this, "SMS reçu - Nouveau quiz chargé", Toast.LENGTH_SHORT).show();
        }
    };

    // Codes de demande de permission
    private static final int PERMISSION_REQUEST_CODE = 123;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        // Vérifier et demander les permissions nécessaires
        checkAndRequestPermissions();
        
        // Réinitialiser le score et le compteur de questions
        score = 0;
        currentQuestionNumber = 0;
        
        // Initialize database helper
        dbHelper = new QuizDbHelper(this);
        
        // Initialize UI components
        questionText = findViewById(R.id.question_text);
        choicesGroup = findViewById(R.id.choices_group);
        choice1 = findViewById(R.id.choice1);
        choice2 = findViewById(R.id.choice2);
        choice3 = findViewById(R.id.choice3);
        choice4 = findViewById(R.id.choice4);
        submitButton = findViewById(R.id.submit_button);
        questionCounter = findViewById(R.id.question_counter);
        
        // Set up submit button click listener
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer();
            }
        });
        
        // Load the first question
        loadNewQuestion();
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        // Vérifier à nouveau les permissions au cas où elles auraient été refusées
        checkAndRequestPermissions();
        
        // Enregistrer les récepteurs de broadcast
        try {
            LocalBroadcastManager.getInstance(this).registerReceiver(
                    callReceiver, new IntentFilter(CallReceiver.ACTION_CALL_RECEIVED));
            LocalBroadcastManager.getInstance(this).registerReceiver(
                    smsReceiver, new IntentFilter(SmsReceiver.ACTION_SMS_RECEIVED));
        } catch (Exception e) {
            Log.e(TAG, "Erreur lors de l'enregistrement des récepteurs", e);
        }
        
        // Recharger un nouveau quiz à chaque reprise
        resetQuiz();
        loadNewQuestion();
    }
    
    @Override
    protected void onPause() {
        super.onPause();
        // Désenregistrer les récepteurs de broadcast
        try {
            LocalBroadcastManager.getInstance(this).unregisterReceiver(callReceiver);
        } catch (Exception e) {
            // Le récepteur n'était pas enregistré
        }
        try {
            LocalBroadcastManager.getInstance(this).unregisterReceiver(smsReceiver);
        } catch (Exception e) {
            // Le récepteur n'était pas enregistré
        }
        
        // Marquer qu'un nouveau quiz doit être chargé au retour
        // Le chargement effectif se fera dans onResume()
    }
    
    private void resetQuiz() {
        // Réinitialiser le score et le compteur de questions
        score = 0;
        currentQuestionNumber = 1;
        // Ne pas réinitialiser le scoreText ici pour éviter les clignotements inutiles
    }
    
    private void loadNewQuestion() {
        // Clear previous selection
        choicesGroup.clearCheck();
        
        // Vérifier si on a atteint le nombre maximum de questions
        if (currentQuestionNumber >= TOTAL_QUESTIONS) {
            showResults();
            return;
        }
        
        // Get a random question from the database
        currentQuestion = dbHelper.getRandomQuestion();
        
        if (currentQuestion != null) {
            // Update the UI with the new question and choices
            questionText.setText(currentQuestion.getQuestionText());
            choice1.setText(currentQuestion.getChoice1());
            choice2.setText(currentQuestion.getChoice2());
            choice3.setText(currentQuestion.getChoice3());
            choice4.setText(currentQuestion.getChoice4());
            
            // Update question counter
            currentQuestionNumber++;
            updateQuestionCounter();
        } else {
            // No questions in the database
            questionText.setText("No questions available");
            choice1.setVisibility(View.GONE);
            choice2.setVisibility(View.GONE);
            choice3.setVisibility(View.GONE);
            choice4.setVisibility(View.GONE);
            submitButton.setEnabled(false);
        }
    }
    
    private void updateQuestionCounter() {
        if (questionCounter != null) {
            questionCounter.setText(String.format("Question %d/%d", currentQuestionNumber, TOTAL_QUESTIONS));
        }
    }
    
    private void checkAnswer() {
        int selectedId = choicesGroup.getCheckedRadioButtonId();
        
        if (selectedId == -1) {
            // No option selected
            Toast.makeText(this, "Veuillez sélectionner une réponse", Toast.LENGTH_SHORT).show();
            return;
        }
        
        // Determine which radio button was selected
        int selectedChoice = 0;
        if (selectedId == R.id.choice1) {
            selectedChoice = 1;
        } else if (selectedId == R.id.choice2) {
            selectedChoice = 2;
        } else if (selectedId == R.id.choice3) {
            selectedChoice = 3;
        } else if (selectedId == R.id.choice4) {
            selectedChoice = 4;
        }
        
        // Check if the answer is correct
        boolean isCorrect = (selectedChoice == currentQuestion.getCorrectAnswer());
        
        // Update score if answer is correct
        if (isCorrect) {
            score++;
            Toast.makeText(this, "Correct !", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Incorrect. La bonne réponse est : " + 
                    getCorrectAnswerText(), Toast.LENGTH_LONG).show();
        }
        
        // Vérifier si le quiz est terminé
        if (currentQuestionNumber >= TOTAL_QUESTIONS) {
            // Petite pause avant d'afficher les résultats
            questionText.postDelayed(new Runnable() {
                @Override
                public void run() {
                    showResults();
                }
            }, 1000);
        } else {
            // Charge une nouvelle question après un court délai
            questionText.postDelayed(new Runnable() {
                @Override
                public void run() {
                    loadNewQuestion();
                }
            }, 1000);
        }
    }
    
    private void showResults() {
        Intent intent = new Intent(this, ResultsActivity.class);
        intent.putExtra("SCORE", score);
        intent.putExtra("TOTAL_QUESTIONS", TOTAL_QUESTIONS);
        startActivity(intent);
        finish();
    }
    
    // Vérifier et demander les permissions nécessaires
    private void checkAndRequestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            List<String> permissionsNeeded = new ArrayList<>();
            
            // Vérifier les permissions pour les appels téléphoniques
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) 
                    != PackageManager.PERMISSION_GRANTED) {
                permissionsNeeded.add(Manifest.permission.READ_PHONE_STATE);
            }
            
            // Vérifier les permissions pour les SMS (uniquement pour Android 4.4+)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) 
                        != PackageManager.PERMISSION_GRANTED) {
                    permissionsNeeded.add(Manifest.permission.RECEIVE_SMS);
                }
            }
            
            // Demander les permissions manquantes
            if (!permissionsNeeded.isEmpty()) {
                ActivityCompat.requestPermissions(this, 
                    permissionsNeeded.toArray(new String[0]), 
                    PERMISSION_REQUEST_CODE);
            }
        }
    }
    
    // Gérer la réponse à la demande de permission
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, 
                                         @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            for (int i = 0; i < permissions.length; i++) {
                if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                    Log.d(TAG, "Permission accordée: " + permissions[i]);
                } else {
                    Log.d(TAG, "Permission refusée: " + permissions[i]);
                    // Afficher un message à l'utilisateur
                    Toast.makeText(this, "Certaines fonctionnalités ne seront pas disponibles sans les permissions nécessaires", 
                                 Toast.LENGTH_LONG).show();
                }
            }
        }
    }
    
    private String getCorrectAnswerText() {
        if (currentQuestion == null) return "";
        switch (currentQuestion.getCorrectAnswer()) {
            case 1: return currentQuestion.getChoice1();
            case 2: return currentQuestion.getChoice2();
            case 3: return currentQuestion.getChoice3();
            case 4: return currentQuestion.getChoice4();
            default: return "";
        }
    }
}
