package com.example.quizapp.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.quizapp.model.Question;

import java.util.ArrayList;
import java.util.List;

public class QuizDbHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "QuizApp.db";
    private static final int DATABASE_VERSION = 1;

    // Table name
    private static final String TABLE_QUESTIONS = "questions";
    
    // Table columns
    private static final String KEY_ID = "id";
    private static final String KEY_QUESTION = "question";
    private static final String KEY_CHOICE1 = "choice1";
    private static final String KEY_CHOICE2 = "choice2";
    private static final String KEY_CHOICE3 = "choice3";
    private static final String KEY_CHOICE4 = "choice4";
    private static final String KEY_CORRECT_ANSWER = "correct_answer";

    // Create table SQL query
    private static final String CREATE_TABLE_QUESTIONS = 
            "CREATE TABLE " + TABLE_QUESTIONS + "("
                    + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + KEY_QUESTION + " TEXT,"
                    + KEY_CHOICE1 + " TEXT,"
                    + KEY_CHOICE2 + " TEXT,"
                    + KEY_CHOICE3 + " TEXT,"
                    + KEY_CHOICE4 + " TEXT,"
                    + KEY_CORRECT_ANSWER + " INTEGER" + ")";

    public QuizDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create tables
        db.execSQL(CREATE_TABLE_QUESTIONS);
        
        // Insert sample questions
        addSampleQuestions(db);
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_QUESTIONS);
        // Create tables again
        onCreate(db);
    }

    // Add sample questions to the database
    private void addSampleQuestions(SQLiteDatabase db) {
        List<Question> questions = new ArrayList<>();
        
        // Add sample questions
        questions.add(new Question("Quelle est la capitale de la France?",
                "Londres", "Berlin", "Paris", "Madrid", 3));
                
        questions.add(new Question("Quel est le plus grand océan du monde?",
                "Océan Atlantique", "Océan Indien", "Océan Arctique", "Océan Pacifique", 4));
                
        questions.add(new Question("Qui a peint la Joconde?",
                "Vincent van Gogh", "Pablo Picasso", "Léonard de Vinci", "Michel-Ange", 3));
                
        questions.add(new Question("Quel est le plus grand mammifère du monde?",
                "Éléphant d'Afrique", "Baleine bleue", "Girafe", "Éléphant de mer", 2));
                
        questions.add(new Question("Combien de continents y a-t-il sur Terre?",
                "5", "6", "7", "8", 3));
        
        // Insert all questions
        for (Question question : questions) {
            ContentValues values = new ContentValues();
            values.put(KEY_QUESTION, question.getQuestionText());
            values.put(KEY_CHOICE1, question.getChoice1());
            values.put(KEY_CHOICE2, question.getChoice2());
            values.put(KEY_CHOICE3, question.getChoice3());
            values.put(KEY_CHOICE4, question.getChoice4());
            values.put(KEY_CORRECT_ANSWER, question.getCorrectAnswer());
            
            db.insert(TABLE_QUESTIONS, null, values);
        }
    }
    
    // Get a random question from the database
    public Question getRandomQuestion() {
        SQLiteDatabase db = this.getReadableDatabase();
        Question question = null;
        
        Cursor cursor = db.query(TABLE_QUESTIONS, 
                new String[]{KEY_ID, KEY_QUESTION, KEY_CHOICE1, KEY_CHOICE2, 
                            KEY_CHOICE3, KEY_CHOICE4, KEY_CORRECT_ANSWER},
                null, null, null, null, "RANDOM()", "1");
        
        if (cursor.moveToFirst()) {
            question = new Question();
            question.setId(cursor.getInt(0));
            question.setQuestionText(cursor.getString(1));
            question.setChoice1(cursor.getString(2));
            question.setChoice2(cursor.getString(3));
            question.setChoice3(cursor.getString(4));
            question.setChoice4(cursor.getString(5));
            question.setCorrectAnswer(cursor.getInt(6));
        }
        
        cursor.close();
        return question;
    }
}
