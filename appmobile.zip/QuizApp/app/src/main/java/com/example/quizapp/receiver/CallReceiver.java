package com.example.quizapp.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

public class CallReceiver extends BroadcastReceiver {
    private static final String TAG = "CallReceiver";
    public static final String ACTION_CALL_RECEIVED = "com.example.quizapp.CALL_RECEIVED";

    @Override
    public void onReceive(Context context, Intent intent) {
        String state = intent.getStringExtra(TelephonyManager.EXTRA_STATE);
        
        if (state != null && state.equals(TelephonyManager.EXTRA_STATE_RINGING)) {
            // Call is ringing
            Log.d(TAG, "Call received");
            
            // Afficher un toast pour le débogage
            Toast.makeText(context, "Appel entrant - Changement de question", Toast.LENGTH_SHORT).show();
            
            // Envoyer un broadcast pour changer la question
            Intent localIntent = new Intent(ACTION_CALL_RECEIVED);
            LocalBroadcastManager.getInstance(context).sendBroadcast(localIntent);
        }
    }
}
