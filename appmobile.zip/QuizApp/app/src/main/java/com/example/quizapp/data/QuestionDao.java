package com.example.quizapp.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import java.util.List;

@Dao
public interface QuestionDao {
    @Query("SELECT * FROM questions ORDER BY RANDOM() LIMIT 1")
    Question getRandomQuestion();

    @Insert
    void insertAll(List<Question> questions);
}
